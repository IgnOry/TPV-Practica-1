#include "FileFormatError.h"



FileFormatError::FileFormatError(string _message):ArkanoidError(_message)
{
}


FileFormatError::~FileFormatError()
{
}
