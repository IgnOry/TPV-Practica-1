#include "FileNotFoundError.h"



FileNotFoundError::FileNotFoundError(string _message):ArkanoidError(_message)
{
}


FileNotFoundError::~FileNotFoundError()
{
}
