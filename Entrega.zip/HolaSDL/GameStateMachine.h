#pragma once
#include <stack>
#include "GameState.h"

class GameStateMachine
{
public:
	stack<GameState*> stack;

	GameStateMachine();
	~GameStateMachine();

	GameState* currentState();
	void changeState(GameState* state);
	/*void setPlayState(GameState* state);
	GameState* getPlayState();*/
	void pushState(GameState* state);
	void popState();
protected:
	GameState* pState;
};

