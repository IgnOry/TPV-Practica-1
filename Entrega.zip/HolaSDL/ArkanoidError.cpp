#include "ArkanoidError.h"

ArkanoidError::~ArkanoidError()
{
}

string ArkanoidError::what()
{
	return what();
}
