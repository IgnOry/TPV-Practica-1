#pragma once
/*#include <SDL_ttf.h> // Puede variar dependiendo de la instalaci�n
#include <string>

using namespace std;

class Font {
private:
	TTF_Font* font = nullptr;
public:
	Font();
	Font( string filename, int size);
	~Font();
	void load( string filename, int size);
	void clean();
	SDL_Surface* generateSurface( string text, SDL_Color color) const;
};*/