#include "GameObject.h"



GameObject::GameObject()
{
}


GameObject::~GameObject()
{
}

void GameObject::saveToFile(ofstream& file)
{
}

void GameObject::loadFromFile(ifstream & file)
{
}
