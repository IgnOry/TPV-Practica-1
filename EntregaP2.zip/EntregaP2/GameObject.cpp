#include "GameObject.h"



GameObject::GameObject()
{
}


GameObject::~GameObject()
{
}

void GameObject::render()
{
}

 void GameObject::update() {

}

void GameObject::handleEvents(SDL_Event event) {

}
