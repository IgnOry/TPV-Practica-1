#pragma once
#include "checkML.h"

class Menu
{
public:
	Menu();
	~Menu();
};

