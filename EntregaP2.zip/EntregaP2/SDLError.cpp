#include "SDLError.h"



SDLError::SDLError(string _message):ArkanoidError(_message)
{

}


SDLError::~SDLError()
{
}
